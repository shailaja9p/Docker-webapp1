package com.patha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.patha.entity.IPLMatchDetailsEntity;

public interface IPLMatchReposirtoy extends JpaRepository<IPLMatchDetailsEntity,Integer>{

}
