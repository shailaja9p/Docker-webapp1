package com.dellux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplCricketMngtProjectUsingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
